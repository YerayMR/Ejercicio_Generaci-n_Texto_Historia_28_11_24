import requests
import json

# Configuración de la API
url = "http://127.0.0.1:5000/v1/completions"
headers = {"Content-Type": "application/json"}

# Función para ajustar la creatividad
def seleccionar_creatividad():
    print("\nSelecciona el nivel de creatividad:")
    print("a) Creatividad alta")
    print("b) Creatividad media")
    print("c) Creatividad baja")
    opcion = input("Opción: ").lower()

    if opcion == "a":
        return 0.9  # Creatividad alta
    elif opcion == "b":
        return 0.7  # Creatividad media
    elif opcion == "c":
        return 0.3  # Creatividad baja
    else:
        print("Opción no válida. Se usará creatividad media por defecto.")
        return 0.7

# Solicitar datos al usuario
def obtener_datos_historia():
    print("Vamos a crear una historia. Por favor, ingresa los siguientes datos:")
    personaje_principal = input("Nombre del personaje principal: ")
    personaje_secundario = input("Nombre del personaje secundario: ")
    lugar = input("Lugar donde transcurre la historia: ")
    accion = input("Acción importante que debe suceder: ")

    return personaje_principal, personaje_secundario, lugar, accion

# Generar historia usando la API
def generar_historia(prompt, temperature):
    body = {
        "prompt": prompt,
        "temperature": temperature,
        "max_tokens": 300  # Ajusta el límite de palabras
    }

    try:
        response = requests.post(url=url, headers=headers, json=body)
        response.raise_for_status()
        message_response = json.loads(response.content.decode("utf-8"))
        return message_response["choices"][0]["text"]
    except requests.exceptions.RequestException as e:
        return f"Error al generar la historia: {e}"

# Programa principal
def main():
    personaje_principal, personaje_secundario, lugar, accion = obtener_datos_historia()
    temperatura = seleccionar_creatividad()

    # Crear el prompt para la historia
    prompt = (
        f"Escribe una historia que incluya a {personaje_principal}, "
        f"un valiente héroe, y a {personaje_secundario}, su leal compañero. La historia ocurre en {lugar}. "
        f"Un evento crucial en el relato es que {accion}. La narración debe ser interesante y creativa."
    )

    print("\nGenerando historia...\n")
    historia = generar_historia(prompt, temperatura)

    print("Historia generada:")
    print(historia)

if __name__ == "__main__":
    main()